# HMS

[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)]

#Screenshots

![alt text](/screenshot/dashboard.png)
![alt text](/screenshot/rooms.png)

# Default data!

  - database name: hms_p
  - default username : admin@admin.com 
  - pass: admin
